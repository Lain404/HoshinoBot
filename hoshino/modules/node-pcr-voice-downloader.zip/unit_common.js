const path = require('path')
const slog = require('single-line-log').stdout
const {get, startDownload} = require('./util')
const BASE_URL = 'unit_common/'

module.exports = async function (config, ids = []) {
    let files = []
    const $ = await get(BASE_URL)
    console.log(`获取列表成功...`)
    let add = (list, start = 0) => {
        for (let i = start; i < list.length; i++) {
            const file = path.join(BASE_URL, list[i].attribs.href)
            files.push({file})
            slog(`加载进度:${i + 1}/${list.length}`)
        }
    }
    if (ids.length > 0) {
        for (let i = 0; i < ids.length; i++) {
            add($(`[data-search] [href^='${ids[i]}']`))
        }
    } else {
        add($('[data-search] a'), 1)
    }
    await startDownload(files)
}
