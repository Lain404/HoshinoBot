const fs = require('fs')
const path = require('path')
const json5 = require('json5')
const unit_common = require('./unit_common')
const {downloadFileList, downloadByIds} = require('./util')
const config = json5.parse(fs.readFileSync(path.join(__dirname, 'config.json5')))

;(async function () {

    if (config.update_unit_battle_voice_all) {
        console.log('开始更新角色战斗语音包')
        await downloadFileList(config, 'unit_battle_voice', config.unit_battle_voice_config.pass)
    }

    if (config.update_unit_common_all) {
        console.log('开始更新角色通常语音包')
        await unit_common(config)
    }

    if (config.update_story_vo_all) {
        console.log('开始更新剧情语音包')
        await downloadFileList(config, 'story_vo')
    }

    //下载单独战斗语音包
    if (config.update_unit_battle_voice_list.length > 0)
        await downloadByIds(config.update_unit_battle_voice_list, 'unit_battle_voice', config.unit_battle_voice_config.pass)

    //下载通常语音包
    if (config.update_unit_common_list.length > 0)
        await unit_common(config, config.update_unit_common_list)

    //下载单独剧情
    if (config.update_story_vo_list.length > 0)
        await downloadByIds(config.update_story_vo_list, 'story_vo')

}())
