安装nodejs  官网http://nodejs.cn/download/ 安装对应平台的环境
完毕后执行 npm install  安装依赖

打开 config.json5 修改配置

执行程序 npm start
