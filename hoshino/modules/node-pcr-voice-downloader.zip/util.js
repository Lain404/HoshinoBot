const fs = require('fs')
const json5 = require('json5')
const path = require('path')
const slog = require('single-line-log').stdout
const progress = require('request-progress')
const rp = require('request-promise')
const cheerio = require('cheerio')
const config = json5.parse(fs.readFileSync(path.join(__dirname, 'config.json5')))

const BASE_URL = config.base_url
const PROXY = config.proxy || ''
const Thread_Count = config.Thread_Count || 20
const CACHE_DIR = path.join(__dirname, 'cache')
const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36'
}
if (config.use_cache && !fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR)
}

async function get(url = '') {
    try {
        return rp({
            uri: BASE_URL + url,
            timeout: 5 * 60 * 1000,
            proxy: PROXY,
            headers,
            originalHostHeaderName: 'Host',
            transform(body) {
                return cheerio.load(body)
            },
        })
    } catch (e) {
        console.log('get request error')
    }

}

let saveDir = config.save_dir
if (!saveDir) {
    saveDir = path.join(process.cwd(), 'priconne')
}

async function download(fileInfo) {
    const url = fileInfo.file
    const pathInfo = path.parse(url)
    const dir = path.join(saveDir, pathInfo.dir)
    const fileName = pathInfo.base
    const file = path.join(dir, fileName)
    const tmp = `${file}.tmp`
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, {recursive: true})
    }
    if (fs.existsSync(file)) {//&& fs.statSync(file).size !== 0
        // console.log(`${fileName}已存在.`)
        return
    }
    return new Promise(((resolve, reject) => {
        try {
            progress(rp({
                uri: BASE_URL + url,
                timeout: 5 * 60 * 1000,
                proxy: PROXY,
                originalHostHeaderName: 'Host',
                headers,
            }))
                .on('progress', (state) => {
                    // slog(`${fileName} 进度:${(state['percent'] * 100).toFixed(2)}% 速度: ${bytes2Size(state['speed'])} 大小: ${bytes2Size(state['size']['transferred'])}/${bytes2Size(state['size']['total'])}`)
                })
                .on('error', (err) => {
                    if (err.code === 'ECONNRESET') return
                    console.log(`\n${file} download error`)
                    console.log(` -> ${err.code}`)
                    reject(err)
                })
                .on('end', async () => {
                    slog(`${fileName} download success!`)
                    fs.renameSync(tmp, file)
                    resolve(fileName)
                })
                .pipe(fs.createWriteStream(`${file}.tmp`))
        } catch (e) {
            console.log('request error .. ')
        }

    }))
}

function bytes2Size(bytes = 0) {
    if (bytes === 0) return '0 B'
    let k = 1024, // or 1024
        sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k))
    return `${(bytes / Math.pow(k, i)).toPrecision(3)} ${sizes[i]}`
}

async function startDownload(files) {
    if (files.length === 0) return
    let files_pro = []
    let index = 0
    const perIndexPath = path.join(CACHE_DIR, `${/^\w+/.exec(files[0].file)[0]}_index`)
    if (config.use_index_cache && fs.existsSync(perIndexPath)) {
        console.log('读取本地进度..')
        index = parseInt(fs.readFileSync(perIndexPath).toString())
        index === -1 && (index = 0)
    }

    for (let i = index; i < files.length; i++) {
        slog(`更新进度:${i + 1}/${files.length} 文件:${files[i].file}`)
        files_pro.push(download(files[i]))
        if (files_pro.length === Thread_Count) {
            await Promise.all(files_pro)
            files_pro = []
            fs.writeFileSync(perIndexPath, `${i}`)
        }
    }
    await Promise.all(files_pro)
    fs.writeFileSync(perIndexPath, `-1`)
    console.log('\n下载完成\n————————————————————')
}

async function downloadNextList(list, perName, passList = [], noCache) {
    list = list.splice(1)
    let files = []
    console.log(`获取成功 一共有 ${list.length} 条数据`)
    let cacheFile = path.join(CACHE_DIR, `${path.parse(perName).base}.json`)
    let cacheFileInfo = path.join(CACHE_DIR, `${path.parse(perName).base}_info.json`)
    if (config.use_cache && !noCache) {
        if (fs.existsSync(cacheFileInfo)) {
            console.log('使用缓存信息')
            if (cheerio(fs.readFileSync(cacheFileInfo).toString()).length === list.length) {
                return startDownload(json5.parse(fs.readFileSync(cacheFile)))
            }
        }
        console.log('木有找到或者有新的缓存信息，正在重新缓存')
    }
    let files_pro = []
    for (let i = 0; i < list.length; i++) {
        const per_path = list[i].attribs.href
        files_pro.push(get(perName + per_path).then($ => {
            let item = []
            $('a').each((i, o) => {
                const href = o.attribs.href
                if (href === '../') return
                if (passList.length > 0 && (new RegExp(passList.join('|'))).exec(href)) return
                const size = parseInt(o.next.data.trim().split(/.+(\D+)/).join(''))
                const file = path.join(perName, per_path, href)
                item.push({size, file})
            })
            files = [...files, ...item]
            slog(`加载进度:${i + 1}/${list.length} 获取 ${per_path} 成功. 一共有 ${files.length} 条`)
        }))
        if (files_pro.length === Thread_Count) {
            await Promise.all(files_pro)
            files_pro = []
        }
    }
    await Promise.all(files_pro)
    if (config.use_cache && !noCache) {
        console.log('刷新缓存信息..')
        fs.writeFileSync(cacheFileInfo, cheerio(list).toString())
        fs.writeFileSync(cacheFile, json5.stringify(files))
    }
    return startDownload(files)
}

async function downloadFileList(config, perName, passList) {
    perName += '/'
    const list = (await get(perName))('a')
    return downloadNextList(list, perName, passList)
}

async function downloadByIds(ids = [], perName, passList) {
    if (ids.length === 0) return
    perName += '/'
    const $ = await get(perName)
    for (let i = 0; i < ids.length; i++) {
        const id = ids[i];
        await downloadNextList($(`[href^='${id}']`), perName, passList, true)
    }
}

module.exports = {
    get,
    startDownload,
    downloadFileList,
    downloadByIds
}
